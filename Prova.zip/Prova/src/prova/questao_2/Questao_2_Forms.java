package prova.questao_2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class Questao_2_Forms extends JFrame {
    private JPanel painel = new JPanel();
    private JButton jButtonjogar = new JButton("Jogar");

    public Questao_2_Forms (){
        this.setTitle("Lotofácil - Interface Gráfica");
        this.setSize(400, 200);
        painel.setLayout(new FlowLayout(FlowLayout.CENTER, 100, 20));
        painel.setBackground(new Color(255, 255, 255));
        painel.add(jButtonjogar);
        jButtonjogar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int portaVazia;
                System.out.println("=> Bem vindo ao jogo Monty Hall");
                String numero = JOptionPane.showInputDialog(null, "Escolha uma porta de 1 a 3: ");
                int portaPremiada = new Random().nextInt(3) + 1;
                int portaEscolhida = Integer.parseInt(numero);
                if (portaEscolhida > 3 || portaEscolhida < 0){
                    System.out.println("Escolha uma porta de 1 a 3");
                    portaEscolhida = dado.nextInt();
                } else if (portaEscolhida == 1 || portaEscolhida == 2 || portaEscolhida == 3) {
                    System.out.println("O apresentador abriu a porta %d que está vazia!".formatted(portaEscolhida));
                    System.out.println("Você deseja trocar de porta? (s/n)");
                    char opcao = dado.next().charAt(0);
                    if (opcao == 'y'){
                        portaVazia = portaEscolhida;
                        System.out.println("Você trocou pela porta %d".formatted(portaEscolhida + 1));

                        portaEscolhida = portaPremiada;
                        System.out.println("Você ganhou!");
                    } else if (opcao == 'n') {
                        System.out.println("Você perdeu! A porta escolhida foi %d".formatted(portaPremiada));
                    }
                    if (portaEscolhida  == portaPremiada){
                        System.out.println("Você ganhou parabéns!");
                    }
                int numeroDigitado = Integer.parseInt(numero);


            }
        }
    }

    public static void main(String[] args) {
        new Questao_2_Forms();
    }
    }
