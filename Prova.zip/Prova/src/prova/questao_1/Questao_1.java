package prova.questao_1;

import java.util.Random;
import java.util.Scanner;

public class Questao_1 {
    public static void main(String[] args) {
        Scanner dado = new Scanner(System.in);
        int portaPremiada = new Random().nextInt(3) + 1;

        int portaEscolhida, portaVazia;


        do {
            System.out.println("=> Bem vindo ao jogo Monty Hall");
            System.out.println("Escolha uma porta de 1 a 3");
            portaEscolhida = dado.nextInt();
            if (portaEscolhida > 3 || portaEscolhida < 0){
                System.out.println("Escolha uma porta de 1 a 3");
                portaEscolhida = dado.nextInt();
            } else if (portaEscolhida == 1 || portaEscolhida == 2 || portaEscolhida == 3) {
                System.out.println("O apresentador abriu a porta %d que está vazia!".formatted(portaEscolhida));
                System.out.println("Você deseja trocar de porta? (s/n)");
                char opcao = dado.next().charAt(0);
                if (opcao == 'y'){
                    portaVazia = portaEscolhida;
                    System.out.println("Você trocou pela porta %d".formatted(portaEscolhida + 1));

                    portaEscolhida = portaPremiada;
                    System.out.println("Você ganhou!");
                } else if (opcao == 'n') {
                    System.out.println("Você perdeu! A porta escolhida foi %d".formatted(portaPremiada));
                }
                if (portaEscolhida  == portaPremiada){
                    System.out.println("Você ganhou parabéns!");
                }


            }


        } while (portaEscolhida == -1);
    }
}
